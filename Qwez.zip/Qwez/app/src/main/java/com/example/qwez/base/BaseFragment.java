package com.example.qwez.base;

public class BaseFragment extends Fragment {
}

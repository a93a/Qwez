package com.example.qwez.base;

import android.arch.lifecycle.ViewModel;

public class BaseViewModel extends ViewModel {




}

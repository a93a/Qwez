package com.example.qwez.base;

public class BaseActivity {
}
